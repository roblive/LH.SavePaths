# ESD-Decrypter
ESD Decrypter Rewrite Script

WIP - Don't use it until I mark a commit with the word STABLE

### New features compared to the original
-Added: Drag and drop functionality - you can now drag an esd file to the bat file.

-Added: Auto-elevation code, no need to right click and run as administrator

-Added: Correct Support for builds higher or equal than 9896

-Added: Progress indicator for esd backup

-Added: Correct Timestamps for the resulted iso, no more iso that differs !

-Added: Command line switches, automate your tasks, and do batch processing !

-Added: Easier Logging support, no more annoying CLS all over the place !

-Updated: WIM-Lib library and CLI front-end

-Updated: ESDDecrypt.exe

-Fixed: A lot of stuff

### Credit for the original script and the tools used :
abbodi1406 for the original script

qad - decryption program

synchronicity - wimlib

murphy78 - original script

nosferati87, NiFu, s1ave77, and any other MDL forums members contributed in the ESD project
